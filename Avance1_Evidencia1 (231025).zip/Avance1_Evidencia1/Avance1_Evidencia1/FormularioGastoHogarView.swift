import SwiftUI

struct FormularioGastoHogarView: View {
    @Environment(\.dismiss) var dismiss

    var gastoExistente: GastoHogar? = nil
    var onGuardar: (GastoHogar) -> Void

    @State private var nombre = ""
    @State private var monto = ""
    @State private var fecha = Date()

    var body: some View {
        NavigationStack {
            Form {
                Section(header: Text("Detalles del gasto")) {
                    TextField("Nombre", text: $nombre)
                    TextField("Monto", text: $monto)
                        .keyboardType(.decimalPad)
                    DatePicker("Fecha", selection: $fecha, displayedComponents: .date)
                }
            }
            .navigationTitle(gastoExistente == nil ? "Nuevo Gasto" : "Editar Gasto")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Guardar") {
                        guard let montoDouble = Double(monto) else { return }

                        let formatter = DateFormatter()
                        formatter.dateFormat = "dd/MM/yyyy"
                        let fechaFormateada = formatter.string(from: fecha)

                        let nuevoGasto = GastoHogar(
                            id: gastoExistente?.id ?? UUID(),
                            nombre: nombre,
                            monto: montoDouble,
                            fecha: fechaFormateada
                        )

                        onGuardar(nuevoGasto)
                        dismiss()
                    }
                }

                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancelar") { dismiss() }
                }
            }
            .onAppear {
                if let gasto = gastoExistente {
                    nombre = gasto.nombre
                    monto = String(format: "%.2f", gasto.monto)

                    let formatter = DateFormatter()
                    formatter.dateFormat = "dd/MM/yyyy"
                    if let fechaParsed = formatter.date(from: gasto.fecha) {
                        fecha = fechaParsed
                    }
                }
            }
        }
    }
}

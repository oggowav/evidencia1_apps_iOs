import SwiftUI

struct GastoHogar: Identifiable, Codable {
    let id: UUID
    let nombre: String
    let monto: Double
    let fecha: String

    init(id: UUID = UUID(), nombre: String, monto: Double, fecha: String) {
        self.id = id
        self.nombre = nombre
        self.monto = monto
        self.fecha = fecha
    }
}

struct GastosHogarView: View {
    @State private var gastos: [GastoHogar] = []
    @State private var mostrarFormulario = false

    var total: Double {
        gastos.reduce(0) { $0 + $1.monto }
    }

    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 16) {
                HStack {
                    Text("Gastos del Hogar")
                        .font(.largeTitle)
                        .bold()
                    Spacer()
                    Button(action: {
                        mostrarFormulario = true
                    }) {
                        Image(systemName: "plus.circle.fill")
                            .font(.title)
                            .foregroundColor(.orange)
                    }
                }

                List(gastos) { gasto in
                    HStack {
                        VStack(alignment: .leading) {
                            Text(gasto.nombre)
                                .font(.headline)
                            Text("Fecha: \(gasto.fecha)")
                                .font(.subheadline)
                                .foregroundColor(.gray)
                        }
                        Spacer()
                        Text(String(format: "$%.2f", gasto.monto))
                            .bold()
                    }
                }
                .listStyle(InsetGroupedListStyle())

                HStack {
                    Spacer()
                    Text("Total: \(String(format: "$%.2f", total))")
                        .font(.title2)
                        .bold()
                    Spacer()
                }

                Spacer()
            }
            .padding()
            .sheet(isPresented: $mostrarFormulario) {
                FormularioGastoHogarView { nuevoGasto in
                    gastos.append(nuevoGasto)
                    saveGastos()
                }
            }
            .onAppear(perform: loadGastos)
        }
    }

    func saveGastos() {
        if let data = try? JSONEncoder().encode(gastos) {
            UserDefaults.standard.set(data, forKey: "gastosHogarGuardados")
        }
    }

    func loadGastos() {
        if let data = UserDefaults.standard.data(forKey: "gastosHogarGuardados"),
           let gastosGuardados = try? JSONDecoder().decode([GastoHogar].self, from: data) {
            gastos = gastosGuardados
        } else {
            gastos = [
                GastoHogar(nombre: "Luz", monto: 45.50, fecha: "02/09/2025"),
                GastoHogar(nombre: "Agua", monto: 30.00, fecha: "05/09/2025"),
                GastoHogar(nombre: "Internet", monto: 60.00, fecha: "06/09/2025"),
                GastoHogar(nombre: "Gas", monto: 25.00, fecha: "10/09/2025")
            ]
        }
    }
}

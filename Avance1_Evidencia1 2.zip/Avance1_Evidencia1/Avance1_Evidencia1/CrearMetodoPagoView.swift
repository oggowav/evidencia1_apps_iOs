import SwiftUI

struct CrearMetodoPagoView: View {
    @Environment(\.dismiss) var dismiss
    @Binding var metodosPago: [String]

    @State private var nuevoMetodo: String = ""

    var body: some View {
        VStack(spacing: 20) {
            TextField("Ingresa el nuevo método de pago", text: $nuevoMetodo)
                .textFieldStyle(.roundedBorder)
                .padding()

            Button("Guardar") {
                if !nuevoMetodo.isEmpty && !metodosPago.contains(nuevoMetodo) {
                    metodosPago.append(nuevoMetodo)
                    dismiss()
                }
            }
            .disabled(nuevoMetodo.isEmpty)
            .padding()
            .background(Color.blue)
            .foregroundColor(.white)
            .cornerRadius(8)

            Spacer()
        }
        .padding()
        .navigationTitle("Nuevo método de pago")
    }
}

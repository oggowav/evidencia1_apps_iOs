import SwiftUI

struct FormularioGastoHogarView: View {
    @Environment(\.dismiss) var dismiss

    @State private var nombre = ""
    @State private var monto = ""
    @State private var fecha = Date()

    var onGuardar: (GastoHogar) -> Void

    var body: some View {
        NavigationStack {
            Form {
                Section(header: Text("Nuevo gasto del hogar")) {
                    TextField("Nombre", text: $nombre)
                    TextField("Monto", text: $monto)
                        .keyboardType(.decimalPad)
                    DatePicker("Fecha", selection: $fecha, displayedComponents: .date)
                }
            }
            .navigationTitle("Agregar Gasto")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Guardar") {
                        guard let montoDouble = Double(monto) else { return }

                        let formatter = DateFormatter()
                        formatter.dateFormat = "dd/MM/yyyy"
                        let fechaFormateada = formatter.string(from: fecha)

                        let nuevoGasto = GastoHogar(
                            nombre: nombre,
                            monto: montoDouble,
                            fecha: fechaFormateada
                        )

                        onGuardar(nuevoGasto)
                        dismiss()
                    }
                }

                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancelar") {
                        dismiss()
                    }
                }
            }
        }
    }
}

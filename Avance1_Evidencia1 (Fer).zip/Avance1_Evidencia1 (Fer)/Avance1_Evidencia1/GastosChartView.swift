//
//  GastosChartView.swift
//  Avance1_Evidencia1
//
//  Created by Alumno on 23/10/25.
//

// GastosChartView.swift


import SwiftUI
import Charts

struct Gasto: Identifiable, Codable {
    let id: UUID
    let nombre: String
    let monto: Double
    let fecha: String
}

struct GastoHogar: Identifiable, Codable {
    let id: UUID
    let nombre: String
    let monto: Double
    let fecha: String
}

struct CategoryAmount: Identifiable, Equatable {
    let id = UUID()
    let category: String
    let amount: Double
    var percentage: Double = 0
}

// MARK: - Vista del gráfico de pastel

struct PieSlice: Shape {
    var startAngle: Angle
    var endAngle: Angle

    func path(in rect: CGRect) -> Path {
        var path = Path()
        let center = CGPoint(x: rect.midX, y: rect.midY)
        let radius = min(rect.width, rect.height) / 2
        path.move(to: center)
        path.addArc(center: center,
                    radius: radius,
                    startAngle: startAngle - Angle(degrees: 90),
                    endAngle: endAngle - Angle(degrees: 90),
                    clockwise: false)
        path.closeSubpath()
        return path
    }
}

struct PieChartView: View {
    let data: [CategoryAmount]
    let colors: [Color]

    var body: some View {
        GeometryReader { geo in
            let rect = geo.frame(in: .local)
            let center = CGPoint(x: rect.midX, y: rect.midY)
            let total = data.reduce(0) { $0 + $1.amount }

            // Precalcular los ángulos
            let slices = data.enumerated().map { index, entry -> (start: Angle, end: Angle, color: Color) in
                let startDegrees = data[..<index].reduce(0) { $0 + ($1.amount / max(total, 1)) * 360 }
                let endDegrees = startDegrees + (entry.amount / max(total, 1)) * 360
                return (start: Angle(degrees: startDegrees),
                        end: Angle(degrees: endDegrees),
                        color: colors[index % colors.count])
            }

            ZStack {
                ForEach(Array(slices.enumerated()), id: \.offset) { _, slice in
                    PieSlice(startAngle: slice.start, endAngle: slice.end)
                        .fill(slice.color)
                }

                VStack {
                    Text("Total")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    Text(String(format: "$%.2f", total))
                        .font(.headline)
                }
                .position(center)
            }
        }
        .aspectRatio(1, contentMode: .fit)
    }
}


// MARK: - Vista principal

struct GastosChartView: View {
    @State private var categoryAmounts: [CategoryAmount] = []
    @State private var showPie = true

    private let palette: [Color] = [
        Color(red: 0.65, green: 0.90, blue: 0.70), // Verde pastel
        Color(red: 1.00, green: 0.80, blue: 0.60)  // Naranja pastel
    ]


    var body: some View {
        NavigationStack {
            VStack(spacing: 16) {
                Picker("", selection: $showPie) {
                    Text("Pastel").tag(true)
                    Text("Barras").tag(false)
                }
                .pickerStyle(SegmentedPickerStyle())
                .padding(.horizontal)

                if showPie {
                    PieChartView(data: categoryAmounts, colors: palette)
                        .padding()
                        .frame(height: 300)
                        .animation(.easeInOut, value: categoryAmounts)
                } else {
                    if #available(iOS 16.0, *) {
                        Chart {
                            ForEach(categoryAmounts) { entry in
                                BarMark(
                                    x: .value("Categoría", entry.category),
                                    y: .value("Monto", entry.amount)
                                )
                                .foregroundStyle(by: .value("Categoría", entry.category))
                                .annotation(position: .top) {
                                    Text(String(format: "$%.0f", entry.amount))
                                        .font(.caption2)
                                }
                            }
                        }
                        .frame(height: 300)
                        .padding(.horizontal)
                        .animation(.easeInOut, value: categoryAmounts)
                    } else {
                        Text("Gráfica de barras requiere iOS 16+")
                            .foregroundColor(.secondary)
                    }
                }

                VStack(alignment: .leading, spacing: 8) {
                    ForEach(Array(categoryAmounts.enumerated()), id: \.element.id) { idx, cat in
                        HStack {
                            RoundedRectangle(cornerRadius: 4)
                                .fill(palette[idx % palette.count])
                                .frame(width: 20, height: 12)
                            Text(cat.category)
                            Spacer()
                            Text(String(format: "$%.2f (%.0f%%)", cat.amount, cat.percentage * 100))
                                .foregroundColor(.secondary)
                                .font(.caption)
                        }
                    }
                }
                .padding(.horizontal)

                Spacer()
            }
            .navigationTitle("Resumen de gastos")
            .onAppear(perform: loadAndAggregate)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: loadAndAggregate) {
                        Image(systemName: "arrow.clockwise")
                    }
                }
            }
        }
    }


    // MARK: - Carga y cálculo de datos

    func loadAndAggregate() {
        // Recuperar datos de UserDefaults
        var suscripciones: [Gasto] = []
        var hogar: [GastoHogar] = []

        if let data = UserDefaults.standard.data(forKey: "gastosGuardados"),
           let decoded = try? JSONDecoder().decode([Gasto].self, from: data) {
            suscripciones = decoded
        }

        if let dataH = UserDefaults.standard.data(forKey: "gastosHogarGuardados"),
           let decodedH = try? JSONDecoder().decode([GastoHogar].self, from: dataH) {
            hogar = decodedH
        }

        // Sumar por categoría
        var map: [String: Double] = [:]
        map["Suscripciones"] = suscripciones.reduce(0) { $0 + $1.monto }
        map["Hogar"] = hogar.reduce(0) { $0 + $1.monto }

        // Si después agregas otras categorías, añádelas aquí:
        // map["Entretenimiento"] = ...

        let totalAll = map.values.reduce(0, +)
        var arr = map.map {
            CategoryAmount(category: $0.key,
                           amount: $0.value,
                           percentage: totalAll > 0 ? ($0.value / totalAll) : 0)
        }

        arr.sort { $0.amount > $1.amount }

        // Datos demo si no hay nada
        if arr.isEmpty || totalAll == 0 {
            arr = [
                CategoryAmount(category: "Suscripciones", amount: 46.97, percentage: 0.55),
                CategoryAmount(category: "Hogar", amount: 38.5, percentage: 0.45)
            ]
        }

        withAnimation {
            categoryAmounts = arr
        }
    }
}

// MARK: - Preview

struct GastosChartView_Previews: PreviewProvider {
    static var previews: some View {
        GastosChartView()
    }
}

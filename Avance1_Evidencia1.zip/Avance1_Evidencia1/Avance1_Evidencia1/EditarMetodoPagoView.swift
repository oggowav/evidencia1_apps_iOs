import SwiftUI

struct EditarMetodoPagoView: View {
    let metodo: String
    var onGuardar: (String) -> Void

    @Environment(\.dismiss) var dismiss
    @State private var nuevoMetodo: String = ""

    var body: some View {
        NavigationStack {
            Form {
                TextField("Editar método de pago", text: $nuevoMetodo)
            }
            .navigationTitle("Editar método")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Guardar") {
                        onGuardar(nuevoMetodo)
                        dismiss()
                    }
                    .disabled(nuevoMetodo.isEmpty)
                }
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancelar") { dismiss() }
                }
            }
        }
        .onAppear {
            nuevoMetodo = metodo
        }
    }
}

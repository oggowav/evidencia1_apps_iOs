import SwiftUI

struct Gasto: Identifiable, Codable {
    let id: UUID
    let nombre: String
    let monto: Double
    let fecha: String

    init(id: UUID = UUID(), nombre: String, monto: Double, fecha: String) {
        self.id = id
        self.nombre = nombre
        self.monto = monto
        self.fecha = fecha
    }
}

struct GastosSuscripcionesView: View {
    @State private var gastos: [Gasto] = []

    @State private var mostrarFormulario = false

    var total: Double {
        gastos.reduce(0) { $0 + $1.monto }
    }

    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 16) {
                HStack {
                    Text("Mis Suscripciones")
                        .font(.largeTitle)
                        .bold()
                    Spacer()
                    Button(action: {
                        mostrarFormulario = true
                    }) {
                        Image(systemName: "plus.circle.fill")
                            .font(.title)
                            .foregroundColor(.blue)
                    }
                }

                List(gastos) { gasto in
                    HStack {
                        VStack(alignment: .leading) {
                            Text(gasto.nombre)
                                .font(.headline)
                            Text("Fecha: \(gasto.fecha)")
                                .font(.subheadline)
                                .foregroundColor(.gray)
                        }
                        Spacer()
                        Text(String(format: "$%.2f", gasto.monto))
                            .bold()
                    }
                }
                .listStyle(InsetGroupedListStyle())

                HStack {
                    Spacer()
                    Text("Total: \(String(format: "$%.2f", total))")
                        .font(.title2)
                        .bold()
                    Spacer()
                }

                Spacer()
            }
            .padding()
            .sheet(isPresented: $mostrarFormulario) {
                FormularioGastoView { nuevoGasto in
                    gastos.append(nuevoGasto)
                    saveGastos()
                }
            }
            .onAppear(perform: loadGastos)
        }
    }

    func saveGastos() {
        if let data = try? JSONEncoder().encode(gastos) {
            UserDefaults.standard.set(data, forKey: "gastosGuardados")
        }
    }

    func loadGastos() {
        if let data = UserDefaults.standard.data(forKey: "gastosGuardados"),
           let gastosGuardados = try? JSONDecoder().decode([Gasto].self, from: data) {
            gastos = gastosGuardados
        } else {
            gastos = [
                Gasto(nombre: "Netflix", monto: 15.99, fecha: "01/09/2025"),
                Gasto(nombre: "Spotify", monto: 9.99, fecha: "03/09/2025"),
                Gasto(nombre: "Amazon Prime", monto: 12.99, fecha: "05/09/2025"),
                Gasto(nombre: "Disney+", monto: 7.99, fecha: "10/09/2025")
            ]
        }
    }
}

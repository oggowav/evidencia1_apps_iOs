import SwiftUI

struct SelectorMetodoPagoView: View {
    @Environment(\.dismiss) var dismiss
    @Binding var metodoPago: String

    @AppStorage("metodosPago") private var metodosData: Data = Data()
    @State private var metodosPago: [String] = []
    @State private var metodoEnEdicion: String = ""
    @State private var mostrandoEdicion = false

    var body: some View {
        NavigationStack {
            VStack {
                List {
                    ForEach(metodosPago, id: \.self) { metodo in
                        HStack {
                            Button(action: {
                                metodoPago = metodo
                                dismiss()
                            }) {
                                HStack {
                                    Text(metodo)
                                    if metodoPago == metodo {
                                        Spacer()
                                        Image(systemName: "checkmark.circle.fill")
                                            .foregroundColor(.blue)
                                    }
                                }
                            }
                            .buttonStyle(PlainButtonStyle())

                            Spacer()

                            Button(action: {
                                metodoEnEdicion = metodo
                                mostrandoEdicion = true
                            }) {
                                Image(systemName: "pencil")
                                    .foregroundColor(.orange)
                            }
                            .buttonStyle(BorderlessButtonStyle())

                            // Botón de eliminar
                            Button(action: {
                                eliminarMetodo(metodo)
                            }) {
                                Image(systemName: "trash")
                                    .foregroundColor(.red)
                            }
                            .buttonStyle(BorderlessButtonStyle())
                        }
                    }
                }

                NavigationLink(destination:
                    CrearMetodoPagoView(
                        metodosPago: $metodosPago,
                        onGuardar: {
                            guardarMetodos()
                        })
                ) {
                    Label("Agregar método de pago", systemImage: "plus.circle.fill")
                        .foregroundColor(.blue)
                }
                .padding()
            }
            .navigationTitle("Seleccionar método")
            .onAppear(perform: cargarMetodos)
            .sheet(isPresented: $mostrandoEdicion) {
                EditarMetodoPagoView(
                    metodo: metodoEnEdicion,
                    onGuardar: { nuevo in
                        editarMetodoViejo(viejo: metodoEnEdicion, nuevo: nuevo)
                        mostrandoEdicion = false
                    }
                )
            }
        }
    }

    func eliminarMetodo(_ metodo: String) {
        metodosPago.removeAll { $0 == metodo }
        guardarMetodos()
        
        if metodo == metodoPago {
            metodoPago = ""
        }
    }

    func editarMetodoViejo(viejo: String, nuevo: String) {
        if let index = metodosPago.firstIndex(of: viejo) {
            metodosPago[index] = nuevo
            guardarMetodos()
            
            if metodoPago == viejo {
                metodoPago = nuevo
            }
        }
    }

    func guardarMetodos() {
        if let data = try? JSONEncoder().encode(metodosPago) {
            metodosData = data
        }
    }

    func cargarMetodos() {
        if let decoded = try? JSONDecoder().decode([String].self, from: metodosData),
           !decoded.isEmpty {
            metodosPago = decoded
        } else {
            metodosPago = [
                "Visa terminada en 1234",
                "Mastercard terminada en 9876",
                "PayPal - oscar@example.com"
            ]
        }
    }
}

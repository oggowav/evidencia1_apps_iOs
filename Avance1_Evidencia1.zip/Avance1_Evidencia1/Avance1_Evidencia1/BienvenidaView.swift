import SwiftUI

struct BienvenidaView: View {
    let buttonWidth: CGFloat = 220

    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                Text("¡Bienvenido!")
                    .font(.largeTitle)
                    .bold()

                NavigationLink("Ver gastos de suscripciones") {
                    GastosSuscripcionesView()
                }
                .frame(width: buttonWidth)
                .padding()
                .background(Color.green)
                .foregroundColor(.white)
                .cornerRadius(8)

                NavigationLink("Ver gastos del hogar") {
                    GastosHogarView()
                }
                .frame(width: buttonWidth)
                .padding()
                .background(Color.orange)
                .foregroundColor(.white)
                .cornerRadius(8)

                Spacer()
            }
            .padding()
        }
    }
}

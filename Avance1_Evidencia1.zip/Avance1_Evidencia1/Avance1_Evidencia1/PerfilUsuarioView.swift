import SwiftUI

struct PerfilUsuarioView: View {
    @Environment(\.dismiss) var dismiss
    @AppStorage("metodoPago") private var metodoPago: String = "Visa terminada en 1234"
    @State private var mostrarSelectorPago = false
    @State private var irALogin = false

    var body: some View {
        NavigationStack {
            VStack(spacing: 30) {
                VStack(spacing: 10) {
                    Image(systemName: "person.crop.circle.fill")
                        .resizable()
                        .frame(width: 100, height: 100)
                        .foregroundColor(.blue)

                    Text("Oscar Gonzalez")
                        .font(.title)
                        .bold()

                    Text("oscar@example.com")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }

                Divider().padding(.horizontal)

                VStack(spacing: 10) {
                    Text("Método de pago actual")
                        .font(.headline)

                    Text(metodoPago)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)

                    Button(action: {
                        mostrarSelectorPago = true
                    }) {
                        Text("Administrar métodos de pago")
                            .font(.subheadline)
                            .foregroundColor(.blue)
                            .padding(.horizontal, 20)
                            .padding(.vertical, 8)
                            .background(Color(.systemGray6))
                            .cornerRadius(8)
                    }
                }

                Spacer()

                Button(action: {
                    irALogin = true
                }) {
                    Text("Cerrar sesión")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.red)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
            }
            .padding()
            .navigationTitle("Mi Perfil")
            .sheet(isPresented: $mostrarSelectorPago) {
                SelectorMetodoPagoView(metodoPago: $metodoPago)
            }
            .navigationDestination(isPresented: $irALogin) {
                LoginView()
            }
        }
    }
}

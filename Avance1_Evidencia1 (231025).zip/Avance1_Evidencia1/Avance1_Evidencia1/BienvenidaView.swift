import SwiftUI

struct BienvenidaView: View {
    let buttonWidth: CGFloat = 220

    @State private var totalSuscripciones: Double = 0
    @State private var totalHogar: Double = 0

    var totalGeneral: Double {
        totalSuscripciones + totalHogar
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 30) {

                    VStack(spacing: 8) {
                        Text("¡Bienvenido!")
                            .font(.largeTitle)
                            .bold()
                        Text("Resumen de tus gastos")
                            .font(.title3)
                            .foregroundColor(.gray)
                    }
                    .padding(.top, 30)

                    VStack(spacing: 16) {
                        resumenRow(
                            titulo: "Suscripciones",
                            valor: totalSuscripciones,
                            color: .blue,
                            icono: "play.circle.fill"
                        )

                        resumenRow(
                            titulo: "Gastos del Hogar",
                            valor: totalHogar,
                            color: .orange,
                            icono: "house.fill"
                        )

                        Divider()

                        resumenRow(
                            titulo: "Total General",
                            valor: totalGeneral,
                            color: .green,
                            icono: "sum"
                        )
                    }
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(12)
                    .shadow(color: .gray.opacity(0.2), radius: 5, x: 0, y: 2)
                    .padding(.horizontal)

                    VStack(spacing: 15) {
                        NavigationLink(destination: GastosSuscripcionesView()) {
                            HStack {
                                Image(systemName: "play.circle.fill")
                                Text("Ver Suscripciones")
                                    .fontWeight(.semibold)
                            }
                            .frame(width: buttonWidth)
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                        }

                        NavigationLink(destination: GastosHogarView()) {
                            HStack {
                                Image(systemName: "house.fill")
                                Text("Ver Gastos Del Hogar")
                                    .fontWeight(.semibold)
                            }
                            .frame(width: buttonWidth)
                            .padding()
                            .background(Color.orange)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                        }
                    }

                    Spacer()
                }
                .padding(.bottom, 40)
            }
            .navigationTitle("Inicio")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    NavigationLink(destination: PerfilUsuarioView()) {
                        Image(systemName: "person.circle.fill")
                            .font(.title2)
                            .foregroundColor(.blue)
                    }
                }
            }
            .onAppear {
                cargarTotales()
            }
        }
    }

    @ViewBuilder
    func resumenRow(titulo: String, valor: Double, color: Color, icono: String) -> some View {
        HStack {
            Label(titulo, systemImage: icono)
                .font(.headline)
                .foregroundColor(color)
            Spacer()
            Text(String(format: "$%.2f", valor))
                .font(.headline)
        }
    }

    func cargarTotales() {
        if let data = UserDefaults.standard.data(forKey: "gastosGuardados"),
           let gastosSuscripciones = try? JSONDecoder().decode([Gasto].self, from: data) {
            totalSuscripciones = gastosSuscripciones.reduce(0) { $0 + $1.monto }
        }

        if let data = UserDefaults.standard.data(forKey: "gastosHogarGuardados"),
           let gastosHogar = try? JSONDecoder().decode([GastoHogar].self, from: data) {
            totalHogar = gastosHogar.reduce(0) { $0 + $1.monto }
        }
    }
}
